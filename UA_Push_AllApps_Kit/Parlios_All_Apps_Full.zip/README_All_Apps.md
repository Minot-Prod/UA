# Parlios — All Apps (Sprints 1–3)

_MAJ_: 2025-10-15 19:27

Ce pack contient **15 apps** prêtes Netlify Drop (build.zip + README_DROP + QA_REPORT + Blueprint).

Voir `INVENTORY.json` pour la liste structurée.
