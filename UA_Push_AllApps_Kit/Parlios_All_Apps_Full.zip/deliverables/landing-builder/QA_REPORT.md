# QA_REPORT — Landing Builder

- [x] UI responsive (mobile/desktop)
- [x] Temps de génération mock < 1s (objectif < 10s en prod)
- [x] Téléchargement export OK
- [x] Accessibilité: focus visibles, structure sémantique
- [x] Compatibilité Netlify Drop
_MAJ_: 2025-10-15 19:27
