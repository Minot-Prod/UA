# QA Summary — Base44 Dashboard

- **Lighthouse (cible)**: ≥ 90 (Mobile & Desktop)
- **Accessibilité**: WCAG AA (focus visible, contrastes suffisants, i18n OK)
- **Performance**: aucune ressource externe, JS minimal
- **i18n**: FR/EN via toggle, `lang` HTML mis à jour
- **Responsive**: grille simple, points de rupture ≥ 900px
- **Notes**: vérifier lisibilité sur écrans très petits (≤320px)
