# DataFlow — Parlios Preview

Prévisualisation **front-only** prête pour **Netlify Drop**.

## Déploiement rapide
1. Téléchargez le fichier ZIP.
2. Ouvrez https://app.netlify.com/drop
3. Glissez-déposez le ZIP → prévisualisation en ligne instantanée.

## Caractéristiques
- UI sombre premium (halo doux) — tokens Parlios
- Responsive mobile/desktop
- i18n FR/EN (toggle)
- Accessibilité AA (WCAG)
- Aucune dépendance externe

## Contenu
- `index.html`
- `manifest.webmanifest`
- `assets/` (logo + icônes PNG)
- `README.md`
- `qa_summary.md`

## Licence
Usage interne Parlios pour tests/démos.
